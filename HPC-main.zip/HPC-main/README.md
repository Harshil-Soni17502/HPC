# HPC
## OpenMP + MPI based implementation of Merge Sort Algorithm
